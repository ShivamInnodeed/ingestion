"""Embedding Service - Internal library for generating text embeddings."""

from embedding_service.core import EmbeddingService, create_embedding_service
from embedding_service.exceptions import (
    EmbeddingError,
    InvalidInputError,
    ModelLoadError,
    ModelNotFoundError,
)

__all__ = [
    "EmbeddingService",
    "create_embedding_service",
    "EmbeddingError",
    "InvalidInputError",
    "ModelLoadError",
    "ModelNotFoundError",
]

__version__ = "0.1.0"
