"""Core embedding service implementation."""

from pathlib import Path
from typing import List

from embedding_service.config import get_model_path
from embedding_service.exceptions import InvalidInputError, ModelNotFoundError
from embedding_service.local_model import LocalModelHandler


class EmbeddingService:
    """Main service class for generating text embeddings."""

    def __init__(
        self,
        model_name: str,
        **kwargs,
    ):
        """
        Initialize the embedding service.

        The model directory is automatically resolved from config based on
        the current environment. The model must exist at the resolved path.

        Args:
            model_name: Name of the model to use (must exist in models directory)
            **kwargs: Additional configuration options (unused for now)

        Raises:
            ModelNotFoundError: If the model directory doesn't exist
            ModelLoadError: If the model fails to load
        """
        self.model_name = model_name

        # Get model path from config (based on current environment)
        model_path = get_model_path(model_name)
        self.model_path = model_path

        # Check if model directory exists - this is the source of truth
        model_dir = Path(model_path)
        if not model_dir.exists():
            raise ModelNotFoundError(
                f"Model '{model_name}' not found at {model_path}. "
                f"Please ensure the model is installed in the models directory "
                f"for the current environment."
            )

        # All models are local - use LocalModelHandler
        # LocalModelHandler will validate the directory and load the model
        self.handler = LocalModelHandler(model_path)
        self._is_local = True

    def _validate_input(self, text: str) -> None:
        """
        Validate input text.

        Args:
            text: Input text to validate

        Raises:
            InvalidInputError: If input is invalid
        """
        if not isinstance(text, str):
            raise InvalidInputError(
                f"Input must be a string, got {type(text).__name__}"
            )
        if not text.strip():
            raise InvalidInputError("Input text cannot be empty")

    def get_embedding(self, text: str) -> List[float]:
        """
        Generate embedding for a single text string (synchronous).

        Args:
            text: Input text string

        Returns:
            List of floats representing the embedding vector

        Raises:
            InvalidInputError: If input is invalid
        """
        self._validate_input(text)
        return self.handler.get_embedding(text)

    async def async_get_embedding(self, text: str) -> List[float]:
        """
        Generate embedding for a single text string (asynchronous).

        Args:
            text: Input text string

        Returns:
            List of floats representing the embedding vector

        Raises:
            InvalidInputError: If input is invalid
        """
        self._validate_input(text)
        return await self.handler.async_get_embedding(text)

    def get_embeddings(self, texts: List[str]) -> List[List[float]]:
        """
        Generate embeddings for multiple text strings (synchronous).

        Args:
            texts: List of input text strings

        Returns:
            List of embedding vectors

        Raises:
            InvalidInputError: If input is invalid
        """
        if not isinstance(texts, list):
            raise InvalidInputError(
                f"Input must be a list, got {type(texts).__name__}"
            )
        if not texts:
            raise InvalidInputError("Input list cannot be empty")

        for text in texts:
            self._validate_input(text)

        return self.handler.get_embeddings(texts)

    async def async_get_embeddings(self, texts: List[str]) -> List[List[float]]:
        """
        Generate embeddings for multiple text strings (asynchronous).

        Args:
            texts: List of input text strings

        Returns:
            List of embedding vectors

        Raises:
            InvalidInputError: If input is invalid
        """
        if not isinstance(texts, list):
            raise InvalidInputError(
                f"Input must be a list, got {type(texts).__name__}"
            )
        if not texts:
            raise InvalidInputError("Input list cannot be empty")

        for text in texts:
            self._validate_input(text)

        return await self.handler.async_get_embeddings(texts)

    def close(self) -> None:
        """Close any resources."""
        # Currently no resources to close for local models
        # Reserved for future use if needed
        pass

    async def aclose(self) -> None:
        """Close any resources asynchronously."""
        # Currently no resources to close for local models
        # Reserved for future use if needed
        pass


def create_embedding_service(
    model_name: str = "all-MiniLM-L6-v2",
    **kwargs,
) -> EmbeddingService:
    """
    Factory function to create a configured EmbeddingService instance.

    Model paths are automatically resolved from embedding_config.toml based on
    the current environment. The model must exist at the resolved path.

    Supported models are determined by what's installed in the models directory
    for the current environment - no hardcoded model list.

    Args:
        model_name: Name of the model to use (must exist in models directory)
        **kwargs: Additional configuration options (reserved for future use)

    Returns:
        Configured EmbeddingService instance

    Raises:
        ModelNotFoundError: If the model directory doesn't exist
        ModelLoadError: If the model fails to load

    Examples:
        >>> # Use any model that exists in the models directory
        >>> service = create_embedding_service("all-MiniLM-L6-v2")
        >>> service = create_embedding_service("e5-mistral-7b-instruct")
        >>> service = create_embedding_service("any-future-model")
    """
    return EmbeddingService(
        model_name=model_name,
        **kwargs,
    )
