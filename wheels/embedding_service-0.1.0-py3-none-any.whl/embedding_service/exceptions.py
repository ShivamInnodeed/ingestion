"""Custom exceptions for the embedding service."""


class EmbeddingError(Exception):
    """Base exception for all embedding service errors."""

    pass


class InvalidInputError(EmbeddingError):
    """Raised when input validation fails."""

    pass


class ModelNotFoundError(EmbeddingError):
    """Raised when a model path doesn't exist or is invalid."""

    pass


class ModelLoadError(EmbeddingError):
    """Raised when a model fails to load."""

    pass
