"""Configuration for model path resolution (config-file only)."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Dict

CONFIG_FILENAME = "embedding_config.toml"


def _config_search_dirs() -> list[Path]:
    """
    Return directories to search for embedding_config.toml, in order.

    - EMBEDDING_CONFIG_PATH: explicit directory (if set)
    - Current working directory: so users can override in their project
    - Package directory: config bundled inside src/embedding_service/
    """
    search_dirs: list[Path] = []

    env_path = os.environ.get("EMBEDDING_CONFIG_PATH")
    if env_path:
        search_dirs.append(Path(env_path).expanduser().resolve())

    search_dirs.append(Path.cwd())

    # Config lives next to this module (src/embedding_service/embedding_config.toml)
    package_dir = Path(__file__).resolve().parent
    if package_dir not in search_dirs:
        search_dirs.append(package_dir)

    return search_dirs


def _find_config_path() -> Path:
    """Return the path to embedding_config.toml, or raise if not found."""
    for directory in _config_search_dirs():
        cfg_path = directory / CONFIG_FILENAME
        if cfg_path.is_file():
            return cfg_path

    searched = _config_search_dirs()
    raise RuntimeError(
        f"Config file not found: {CONFIG_FILENAME} was not found in any of: "
        f"{[str(d) for d in searched]}. "
        f"Place {CONFIG_FILENAME} in your project directory, or set EMBEDDING_CONFIG_PATH."
    )


def _load_config() -> Dict[str, Any]:
    """Load and parse embedding_config.toml."""
    try:
        import tomllib  # Python 3.11+
    except ImportError:  # pragma: no cover - for older runtimes
        import tomli as tomllib  # type: ignore[assignment]

    cfg_path = _find_config_path()
    return tomllib.loads(cfg_path.read_text())


def get_model_base_dir() -> Path:
    """
    Get the base directory where models are stored for the current environment.

    - Reads env name from [env].current
    - Reads base dir from [paths].<env_name>

    All environment/path mappings are defined in embedding_config.toml.
    """
    cfg = _load_config()

    try:
        env_section = cfg["env"]
        paths_section = cfg["paths"]
    except KeyError as exc:
        raise RuntimeError(
            f"Invalid {CONFIG_FILENAME}: missing [{exc.args[0]}] section."
        ) from exc

    try:
        env_name = env_section["current"]
    except KeyError as exc:
        raise RuntimeError(
            f"Invalid {CONFIG_FILENAME}: missing [env].current key."
        ) from exc

    if env_name not in paths_section:
        raise RuntimeError(
            f"No path configured for environment '{env_name}' in "
            f"[paths] section of {CONFIG_FILENAME}."
        )

    base_dir = Path(paths_section[env_name])
    return base_dir.expanduser().resolve()


def get_model_path(model_name: str) -> str:
    """
    Get the full path to a specific model directory for the current environment.

    Final path:
        <paths[current_env]> / <model_name>
    """
    base_dir = get_model_base_dir()
    model_path = base_dir / model_name
    return str(model_path.resolve())
