"""Local model handler using sentence-transformers."""

import os
from pathlib import Path
from typing import List, Optional

from sentence_transformers import SentenceTransformer  # type: ignore[import-untyped]

from embedding_service.exceptions import ModelLoadError, ModelNotFoundError


class LocalModelHandler:
    """Handler for local sentence-transformers models."""

    _model_cache: dict[str, SentenceTransformer] = {}

    def __init__(self, model_path: str):
        """
        Initialize the local model handler.

        Args:
            model_path: Path to the pre-installed model directory

        Raises:
            ModelNotFoundError: If the model path doesn't exist
            ModelLoadError: If the model fails to load
        """
        self.model_path = Path(model_path).expanduser().resolve()

        if not self.model_path.exists():
            raise ModelNotFoundError(
                f"Model path does not exist: {self.model_path}. "
                "Please ensure the model is pre-installed at this location."
            )

        if not self.model_path.is_dir():
            raise ModelNotFoundError(
                f"Model path is not a directory: {self.model_path}"
            )

        self._load_model()

    def _load_model(self) -> None:
        """Load the model from disk, using cache if available."""
        cache_key = str(self.model_path)

        if cache_key not in self._model_cache:
            try:
                self._model_cache[cache_key] = SentenceTransformer(
                    str(self.model_path)
                )
            except Exception as e:
                error_msg = str(e)
                # Provide helpful error message for common issues
                if "header too large" in error_msg.lower() or "deserializing" in error_msg.lower():
                    raise ModelLoadError(
                        f"Model files appear to be corrupted or incomplete at {self.model_path}. "
                        f"Error: {error_msg}. "
                        "Please re-download or re-install the model files."
                    ) from e
                else:
                    raise ModelLoadError(
                        f"Failed to load model from {self.model_path}: {error_msg}"
                    ) from e

        self.model = self._model_cache[cache_key]

    def get_embedding(self, text: str) -> List[float]:
        """
        Generate embedding for a single text string (synchronous).

        Args:
            text: Input text string

        Returns:
            List of floats representing the embedding vector
        """
        embedding = self.model.encode(text, convert_to_numpy=True)
        return embedding.tolist()

    async def async_get_embedding(self, text: str) -> List[float]:
        """
        Generate embedding for a single text string (asynchronous).

        Note: sentence-transformers doesn't have native async support,
        but we provide this method for API consistency. It runs in a
        thread pool executor.

        Args:
            text: Input text string

        Returns:
            List of floats representing the embedding vector
        """
        import asyncio

        loop = asyncio.get_event_loop()
        embedding = await loop.run_in_executor(
            None, lambda: self.model.encode(text, convert_to_numpy=True)
        )
        return embedding.tolist()

    def get_embeddings(self, texts: List[str]) -> List[List[float]]:
        """
        Generate embeddings for multiple text strings (synchronous).

        Args:
            texts: List of input text strings

        Returns:
            List of embedding vectors
        """
        embeddings = self.model.encode(texts, convert_to_numpy=True)
        return embeddings.tolist()

    async def async_get_embeddings(self, texts: List[str]) -> List[List[float]]:
        """
        Generate embeddings for multiple text strings (asynchronous).

        Args:
            texts: List of input text strings

        Returns:
            List of embedding vectors
        """
        import asyncio

        loop = asyncio.get_event_loop()
        embeddings = await loop.run_in_executor(
            None, lambda: self.model.encode(texts, convert_to_numpy=True)
        )
        return embeddings.tolist()
